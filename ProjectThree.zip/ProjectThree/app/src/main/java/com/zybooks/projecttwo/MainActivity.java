package com.zybooks.projecttwo;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity{
    private Button loginButton;
    private Button  createAccount;
    private EditText loginUserName;
    private EditText loginPassword;
    private RecyclerView mRecyclerView;

    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState); // creating super method
        setContentView(R.layout.activity_main); // using the variables from activity_main

        mRecyclerView = findViewById(R.id.recycler_view);
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);


        loginButton = findViewById(R.id.submitButton); //using the set id's from each aspect
        loginPassword = findViewById(R.id.accountPassword);
        loginUserName = findViewById(R.id.accountUserName);
        createAccount = findViewById(R.id.newUserButton);

        loginButton.setOnClickListener(view ->{
            String userName = loginUserName.getText().toString(); //getting username and password that user input
            String password = loginPassword.getText().toString();

            /*FIXME add logic for log in
            if (!(loginUserName.length() == userName)){ FIXMME add logic for log in
                // check if user exists in system currently
                //if they do not exist, instruct user to create account, start createAccount activity

            }
            */
        });

        createAccount.setOnClickListener(view->{ // createAccount activity start if user does not already exist
            Intent intent = new Intent(MainActivity.this, createAccount.class);
            startActivity(intent);
        });
    }
}
