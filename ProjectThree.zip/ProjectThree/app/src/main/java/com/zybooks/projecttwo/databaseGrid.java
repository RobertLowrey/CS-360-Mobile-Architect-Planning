package com.zybooks.projecttwo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class databaseGrid extends AppCompatActivity {

    private RecyclerView RecyclerView;
    private DataAdapter dataAdapter;
    private List<dataItems> dataItems;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_grid);

        RecyclerView = findViewById(R.id.recycler_view);
        RecyclerView.setLayoutManager(new LinearLayoutManager(this));

        dataItems = new ArrayList<>();
        dataAdapter = new DataAdapter(dataItems);
        RecyclerView.setAdapter(dataAdapter);

    }

    private class DataAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter {
        public DataAdapter(List<com.zybooks.projecttwo.dataItems> dataItems) {

        }

        public void setOnItemClickListener(DataAdapter.OnItemClickListener onItemClickListener) {

        }

        @NonNull
        @Override
        public androidx.recyclerview.widget.RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return null;
        }

        @Override
        public void onBindViewHolder(@NonNull androidx.recyclerview.widget.RecyclerView.ViewHolder holder, int position) {

        }

        @Override
        public int getItemCount() {
            return 0;
        }

        private class OnItemClickListener {


        }

        private class OnDeleteClickListener {

        }
    }





}