package com.zybooks.projecttwo;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class logInActivity extends AppCompatActivity {
    private DatabaseHelper DatabaseHelper; //creating private variables
    private SQLiteDatabase db;
    private TextView loginUserName;
    private TextView loginPassword;
    private Button login;

    @Override
    protected void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance); // creating super method
        setContentView(R.layout.activity_main); // using the variables from activity_main

        DatabaseHelper = new DatabaseHelper(this);
        db = DatabaseHelper.getReadableDatabase();

        loginUserName =findViewById(R.id.accountUserName);
        loginPassword = findViewById(R.id.accountPassword);
        login = findViewById(R.id.submitButton);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = loginUserName.getText().toString();
                String password = loginPassword.getText().toString();
            }
        });

    }

}
