package com.zybooks.projecttwo;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class createAccount extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private SQLiteDatabase db;
    private TextView createUser;
    private TextView createPassword;
    private Button createAccount;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        setContentView(R.layout.create_account_activity); //using the layout file activity_main

        databaseHelper = new DatabaseHelper(this); //uses a local variable for DatabaseHelper
        db = databaseHelper.getWritableDatabase(); //gets writable database

        createUser = findViewById(R.id.createUser);
        createPassword = findViewById(R.id.createPassword);
        createAccount = findViewById(R.id.createAccount);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = createUser.getText().toString(); //gets user input for username
                String password = createPassword.getText().toString(); //gets input for password

                if (!username.isEmpty() && !password.isEmpty()){
                    ContentValues contValues = new ContentValues();
                    contValues.put(DatabaseHelper.colUserName, username);
                    contValues.put(DatabaseHelper.colPassword, password);

                    long newRowID = db.insert(DatabaseHelper.table, null, contValues);

                    if (newRowID != 1){
                        System.out.println("REGISTRATION SUCCESSFUL!");
                    }
                    else{
                        System.out.println("REGISTRATION NOT SUCCESSFUL TRY AGAIN!");
                    }
                }
            }
        });







    }




}
