package com.zybooks.projecttwo;


import static android.Manifest.permission.SEND_SMS;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SMS_messaging extends AppCompatActivity {

    private Button requestPermissionButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_messaging);

        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        requestPermissionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(SMS_messaging.this, SEND_SMS) == PackageManager.PERMISSION_GRANTED){
                    sendSMS();

                }else{
                    ActivityCompat.requestPermissions(SMS_messaging.this, new String[]{Manifest.permission.SEND_SMS}, 1);
                }
            }
        });
    }

    private void sendSMS() {
        String phoneNumber = "123456789"; //users phone number (still do not know it)

        String SMS = "Hello, Thank you for opting into the applications SMS feature!"; // message that will be sent to the user

        SmsManager smsManager = SmsManager.getDefault(); //smsManager
        smsManager.sendTextMessage(phoneNumber, null, SMS, null, null);

    }

    public void onRequestPermissionResults(int requestCode, String[] permissions, int[] grantResults){
        if (requestCode == 1){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){ //if permission granted
                sendSMS(); //send SMS to user
            }
            else{ //if permission denied
                Toast.makeText(this, "Denied Permission, could not send SMS!", Toast.LENGTH_SHORT).show();

            }
        }
    }
}