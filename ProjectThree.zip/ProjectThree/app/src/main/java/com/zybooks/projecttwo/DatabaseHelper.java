package com.zybooks.projecttwo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseHelper {
    private static String dbName = "inventoryDatabase.db";
    private static int dbVersion = 0;
    public static String table= "users";
    public static String colIDNumber = "ID";
    public static String colUserName = "userName";
    public static String colPassword = "password";

    private String createTable = new StringBuilder().append("CREATE TABLE").append(table).append("(").append(colIDNumber).append("INTEGER PRIMARY KEY AUTOINCREMENT").append(colUserName).append("TEXT,").append(colPassword).append("TEXT,").append(");").toString();

    public DatabaseHelper(Context context){
        super();
    }

    public void onCreate(SQLiteDatabase db){
        db.execSQL(createTable); //creates table if table does not already exist
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("If table exists, DROP TABLE" + table); // if table exists, drop table to create a new version
        onCreate(db); //creates new database
    }

    public SQLiteDatabase getWritableDatabase() {
        return null;
    }

    public SQLiteDatabase getReadableDatabase() {
        return null;
    }
}
